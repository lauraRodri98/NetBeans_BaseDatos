/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectobd;

/**
 *
 * @author usuario
 */
public class Partidos {
    private int codigo;
    private String equipo_local;
    private String equipo_visitante;
    private int puntos_local;
    private int puntos_visitante;
    private String temporada;
    
    Partidos()
    {
        codigo=0;
        equipo_local="";
        equipo_visitante="";
        puntos_local=0;
        puntos_visitante=0;
        temporada="";
    }
    
    Partidos(int codigo, String equipo_local, String equipo_visitante,int puntos_local, int puntos_visitante, String temporada)
    {
        this.codigo = codigo;
        this.equipo_local = equipo_local;
        this.equipo_visitante = equipo_visitante;
        this.puntos_local = puntos_local;
        this.equipo_visitante = equipo_visitante;
        this.temporada = temporada;
    }
    
    public void setCodigo (int codigo)
    {
        this.codigo = codigo;
    }
    
    public void setEquipo_local (String equipo_local)
    {
        this.equipo_local = equipo_local;
    }
    
    public void setEquipo_visitante (String equipo_visitante)
    {
        this.equipo_visitante = equipo_visitante;
    }
    
    public void setPuntos_local (int puntos_local)
    {
        this.puntos_local = puntos_local;
    }
    
    public void setPuntos_visitante(int puntos_visitante)
    {
        this.puntos_visitante = puntos_visitante;
    }
    
    public void setTemporada (String temporada)
    {
        this.temporada = temporada;
    }
    
    public int getCodigo()
    {
        return codigo;
    }
    
    public String getEquipoLocal()
    {
        return equipo_local;
    }
    
    public String getVisitante()
    {
        return equipo_visitante;
    }
    
    public int getPuntosLocal()
    {
        return puntos_local;
    }
    
    public int getPuntosVisitante()
    {
        return puntos_visitante;
    }
    
    public String getTemporada()
    {
        return temporada;
    }
    
    public String toString ()
    {
        return codigo + "|" + equipo_local+ "|" + equipo_visitante + "|" + puntos_local+ "|" + puntos_visitante + "|"  + temporada +'\n';
    }
}

    

