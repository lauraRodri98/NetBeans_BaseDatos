/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectobd;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author usuario
 */
public class ProyectoBD {

    public static void main(String[] args) {
        FramePartidos f = new FramePartidos();
        f.setVisible(true);
        
    }
    
}
