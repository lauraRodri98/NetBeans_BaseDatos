/*
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectobd;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author USUARIO
 */
public class MiRenderer extends DefaultTableCellRenderer {
    Color c1;
    Color c2;
    
    MiRenderer (Color c1, Color c2)
    {
        this.c1 = c1;
        this.c2 = c2;
    }
    
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,int row,int column)
    {
        super.getTableCellRendererComponent (table, value, isSelected, hasFocus, row, column);

        if(row%2==0)
        {
          this.setOpaque(true);
          this.setBackground(c1);

        } else {
          this.setBackground(c2);
          // Restaurar los valores por defecto
        }

        return this;
    }
}
